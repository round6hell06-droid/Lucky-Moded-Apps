/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect } from "react";
import { AnimatePresence, motion } from "motion/react";
import { Terminal as TerminalIcon } from "lucide-react";

import Navbar from "./components/Navbar";
import Hero from "./components/Hero";
import Terminal from "./components/Terminal";
import Marquee from "./components/Marquee";
import GlowingSection from "./components/GlowingSection";
import FeaturedApps from "./components/FeaturedApps";
import Features from "./components/Features";
import Footer from "./components/Footer";
import ParticleBackground from "./components/ParticleBackground";
import FloatingTelegram from "./components/FloatingTelegram";
import DMCAPopup from "./components/DMCAPopup";

export default function App() {
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    // Simulate initial loading and asset optimization time
    const timer = setTimeout(() => {
      setIsLoading(false);
    }, 1500);
    return () => clearTimeout(timer);
  }, []);

  return (
    <main className="min-h-screen bg-black relative">
      <AnimatePresence>
        {isLoading && (
          <motion.div 
            initial={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.5, ease: "easeInOut" }}
            className="fixed inset-0 z-[100] bg-black flex flex-col items-center justify-center"
          >
            <div className="w-16 h-16 rounded-xl bg-[#00ff88]/10 border border-[#00ff88]/30 flex items-center justify-center text-[#00ff88] mb-6 shadow-[0_0_20px_rgba(0,255,136,0.2)]">
              <TerminalIcon className="w-8 h-8 animate-pulse" />
            </div>
            <div className="w-48 h-1 bg-gray-900 rounded-full overflow-hidden relative">
              <motion.div 
                initial={{ x: "-100%" }}
                animate={{ x: "100%" }}
                transition={{ repeat: Infinity, duration: 1, ease: "linear" }}
                className="absolute inset-y-0 left-0 w-1/2 bg-gradient-to-r from-transparent via-[#00ff88] to-transparent"
              />
            </div>
            <div className="font-mono text-[#00ff88]/50 text-xs mt-4 tracking-[0.2em] uppercase pulse-glow">
              Loading SYSTEM...
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Universal Particle Background */}
      <ParticleBackground />
      
      {/* Disclaimer Popup */}
      <DMCAPopup />
      
      {/* Layout Modules matching IRIS structure */}
      <Navbar />
      <Hero />
      <Terminal />
      <Features />
      <Marquee />
      <FeaturedApps />
      <GlowingSection />
      <Footer />
      <FloatingTelegram />
    </main>
  );
}

