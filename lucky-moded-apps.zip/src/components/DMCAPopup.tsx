import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { AlertTriangle } from "lucide-react";

export default function DMCAPopup() {
  const [show, setShow] = useState(false);

  useEffect(() => {
    const hasAccepted = localStorage.getItem("dmca_accepted");
    if (!hasAccepted) {
      // Delay slightly for better UX
      const timer = setTimeout(() => {
        setShow(true);
      }, 2500);
      return () => clearTimeout(timer);
    }
  }, []);

  const handleAccept = () => {
    localStorage.setItem("dmca_accepted", "true");
    setShow(false);
  };

  return (
    <AnimatePresence>
      {show && (
        <div className="fixed inset-0 z-[150] flex items-center justify-center px-4">
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="absolute inset-0 bg-black/80 backdrop-blur-sm"
          />
          <motion.div
            initial={{ opacity: 0, scale: 0.9, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.9, y: 20 }}
            className="relative w-full max-w-md bg-black border border-[#00ff88]/30 rounded-2xl p-6 md:p-8 shadow-[0_0_40px_rgba(0,255,136,0.15)] flex flex-col items-center text-center overflow-hidden"
          >
            {/* Glow effect */}
            <div className="absolute top-0 right-0 w-32 h-32 bg-orange-500/10 blur-[40px] rounded-full pointer-events-none" />
            
            <div className="w-16 h-16 rounded-full bg-orange-500/10 border border-orange-500/30 flex items-center justify-center text-orange-400 mb-6 shadow-[0_0_15px_rgba(249,115,22,0.2)]">
              <AlertTriangle className="w-8 h-8" />
            </div>
            
            <h3 className="font-display font-bold text-2xl text-white mb-4">
              DMCA & Educational Disclaimer
            </h3>
            
            <p className="text-gray-400 text-sm leading-relaxed mb-8">
              All applications and modifications provided on this platform are for <span className="text-[#00ff88] font-medium">educational and research purposes only</span>. We do not host any files on our servers. By continuing to use this site, you agree to these terms.
            </p>
            
            <button 
              onClick={handleAccept}
              className="w-full bg-[#00ff88] text-black font-bold py-3.5 rounded-xl hover:bg-[#00ffa3] transition-colors shadow-[0_0_20px_rgba(0,255,136,0.3)] hover:shadow-[0_0_30px_rgba(0,255,136,0.5)]"
            >
              I Understand & Agree
            </button>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
}
