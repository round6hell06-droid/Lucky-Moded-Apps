import React, { useState, useMemo } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Download, Star, ShieldCheck, Search, Filter, History, ChevronDown, CheckCircle2, Send } from "lucide-react";
import { AppData, FEATURED_APPS } from "../types";

const CATEGORIES = ["All", "Social", "Entertainment", "Games", "Tools", "Education"];
const SORT_OPTIONS = ["Most Downloaded", "Top Rated"];

const AppCard: React.FC<{ app: AppData; index: number; onToast: (msg: string) => void }> = ({ app, index, onToast }) => {
  const [showHistory, setShowHistory] = useState(false);
  const [isDownloading, setIsDownloading] = useState(false);
  const [isDownloaded, setIsDownloaded] = useState(false);
  const [downloadsOffset, setDownloadsOffset] = useState(0);
  const todayDate = new Intl.DateTimeFormat('en-US', { day: 'numeric', month: 'short', year: 'numeric' }).format(new Date());

  const handleDownload = () => {
    setIsDownloading(true);
    onToast(`Opening GetModPC for latest mod...`);
    
    setTimeout(() => {
       setIsDownloading(false);
       setIsDownloaded(true);
       setDownloadsOffset(prev => prev + 1);
       window.open(app.downloadUrl, "_blank", "noopener,noreferrer");

       setTimeout(() => setIsDownloaded(false), 2000);
    }, 1200);
  };
  
  const formatDownloads = (num: number) => {
    if (num >= 1000000) return (num / 1000000).toFixed(1) + "M+";
    if (num >= 1000) return Math.floor(num / 1000) + "K+";
    return num.toString() + "+";
  };

  const currentDownloadsText = formatDownloads(app.downloadsNum + downloadsOffset);

  return (
    <motion.div
      layout
      initial={{ opacity: 0, scale: 0.9 }}
      animate={{ opacity: 1, scale: 1 }}
      exit={{ opacity: 0, scale: 0.9 }}
      transition={{ duration: 0.3 }}
      className="group relative rounded-2xl bg-gradient-to-br from-white/10 to-transparent p-[1px] h-fit"
    >
      <div className="absolute inset-0 rounded-2xl bg-gradient-to-br from-[#00ff88] to-[#00cc66] opacity-0 group-hover:opacity-100 transition-opacity blur-[2px]" />
      
      <div className="relative flex flex-col glass-panel rounded-2xl p-5 overflow-hidden">
        
        {/* Top Badges */}
        <div className="absolute top-4 right-4 flex gap-2 z-10">
          <span className="text-[10px] uppercase tracking-wider font-bold px-2 py-1 rounded-full bg-[#00ff88]/20 text-[#00ff88] border border-[#00ff88]/30">
            Latest Mod
          </span>
        </div>

        {/* Top Section */}
        <div className="flex items-start gap-4 mb-4 z-10 pr-16">
          <div className={`shrink-0 w-14 h-14 rounded-xl ${app.iconBg} flex items-center justify-center text-white text-2xl font-bold shadow-lg shadow-black/50 border border-white/20 overflow-hidden relative p-1`}>
            <img 
              src={app.iconUrl} 
              alt={app.name} 
              loading="lazy"
              className="relative z-10 w-full h-full object-contain rounded-lg bg-white shadow-sm" 
              onError={(e) => { 
                e.currentTarget.style.display = 'none'; 
              }} 
            />
            <span className="absolute text-white z-0">{app.name.substring(0, 1)}</span>
          </div>
          <div>
            <h3 className="font-display font-bold tracking-wide text-lg text-white group-hover:text-[#00ff88] transition-colors leading-tight">
              {app.name}
            </h3>
            <p className="text-gray-400 text-xs mt-1">{app.category}</p>
            <div className="flex items-center gap-2 mt-2">
              <span className="text-[10px] font-mono bg-[#00ff88]/10 text-[#00ff88] border border-[#00ff88]/20 px-1.5 py-0.5 rounded">
                {app.version}
              </span>
            </div>
          </div>
        </div>

        {/* Info Grid */}
        <div className="grid grid-cols-3 gap-2 mb-4 z-10">
          <div className="flex flex-col items-center justify-center bg-black/40 rounded-lg py-2 border border-[#00ff88]/5">
            <div className="flex items-center gap-1 text-[#00ff88] font-mono text-sm">
              <Star className="w-3.5 h-3.5 fill-current" /> {app.rating}
            </div>
            <span className="text-[10px] text-gray-500 uppercase flex-shrink-0 whitespace-nowrap">Rating</span>
          </div>
          <div className="flex flex-col items-center justify-center bg-black/40 rounded-lg py-2 border border-[#00ff88]/5">
            <div className="flex items-center gap-1 text-[#00ff88] font-mono text-sm">
              <Download className="w-3.5 h-3.5" /> 
              <motion.span
                key={currentDownloadsText}
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
                className="inline-block"
              >
                {currentDownloadsText}
              </motion.span>
            </div>
            <span className="text-[10px] text-gray-500 uppercase flex-shrink-0 whitespace-nowrap">Downloads</span>
          </div>
          <div className="flex flex-col items-center justify-center bg-black/40 rounded-lg py-2 border border-[#00ff88]/5">
            <div className="text-gray-300 font-mono text-sm whitespace-nowrap">{app.size}</div>
            <span className="text-[10px] text-gray-500 uppercase flex-shrink-0 whitespace-nowrap">Size</span>
          </div>
        </div>

        {/* Details & Actions */}
        <div className="flex flex-col gap-3 z-10">
          <div className="flex items-center justify-between text-xs">
            <span className="text-gray-400 flex items-center gap-1"><span className="w-1.5 h-1.5 rounded-full bg-[#00ff88]"></span> Updated: {todayDate}</span>
            <span className="text-[#00ff88] flex items-center gap-1"><ShieldCheck className="w-3.5 h-3.5" /> Auto-verified safe</span>
          </div>

          <div className="grid grid-cols-2 gap-2 mt-2">
            <div className="col-span-2 flex flex-col gap-1.5">
              <button 
                onClick={handleDownload} 
                disabled={isDownloading || isDownloaded} 
                className="relative w-full group/btn overflow-hidden rounded-lg bg-[#00ff88] hover:bg-[#00ffa3] border border-[#00ff88] text-black py-3 transition-all duration-300 shadow-[0_0_15px_rgba(0,255,136,0.2)] hover:shadow-[0_0_25px_rgba(0,255,136,0.4)] disabled:opacity-80"
              >
                {!isDownloading && !isDownloaded && <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/40 to-transparent -translate-x-full group-hover/btn:animate-shimmer" />}
                <span className="relative font-bold flex items-center justify-center gap-2">
                  {isDownloading ? (
                    <><div className="w-4 h-4 rounded-full border-2 border-black border-t-transparent animate-spin"></div> Downloading...</>
                  ) : isDownloaded ? (
                    <><CheckCircle2 className="w-4 h-4" /> Downloaded!</>
                  ) : (
                    <><Download className="w-4 h-4" /> Download APK</>
                  )}
                </span>
              </button>
              <div className="text-center w-full">
                <a href="https://t.me/LUCKYXMODZZ" target="_blank" rel="noopener noreferrer" className="text-[10px] text-gray-500 hover:text-[#00ff88] transition-colors inline-flex items-center justify-center w-full gap-1 font-mono">
                  <Send className="w-2.5 h-2.5" /> Download via @LUCKYXMODZZ on Telegram
                </a>
              </div>
            </div>
            
            <button className="w-full bg-black/50 hover:bg-[#00ff88]/10 border border-[#00ff88]/10 hover:border-[#00ff88]/30 text-[#00ff88] text-xs py-2 rounded-lg transition-colors flex items-center justify-center gap-1">
               Request Update
            </button>
            <button 
              onClick={() => setShowHistory(!showHistory)}
              className="w-full bg-black/50 hover:bg-[#00ff88]/10 border border-[#00ff88]/10 hover:border-[#00ff88]/30 text-[#00ff88] text-xs py-2 rounded-lg transition-colors flex items-center justify-center gap-1"
            >
              <History className="w-3 h-3" /> History <ChevronDown className={`w-3 h-3 transition-transform ${showHistory ? 'rotate-180' : ''}`} />
            </button>
          </div>
        </div>

        <AnimatePresence>
          {showHistory && (
            <motion.div
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: "auto", opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              className="overflow-hidden z-10"
            >
              <div className="pt-3 mt-3 border-t border-[#00ff88]/20 text-xs text-[#00ff88]/70 font-mono space-y-2">
                <p className="flex items-center gap-1 text-white">
                  <ShieldCheck className="w-3.5 h-3.5 text-[#00ff88]" /> 
                  Modder Info: <span className="text-[#00ff88]">{app.modder}</span>
                  <title>Verified Developer</title>
                </p>
                <p>• {app.version} - Current (Stability fixes)</p>
                <p>• v{parseFloat(app.version.replace('v', '')) - 0.1 || '0'} - Initial release</p>
                
                <a href={app.repoUrl} target="_blank" rel="noopener noreferrer" className="mt-2 inline-flex items-center gap-1 px-2 py-1.5 bg-[#00ff88]/10 hover:bg-[#00ff88]/20 text-[#00ff88] rounded-md transition-colors w-full justify-center">
                  View Source Repository
                </a>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        <div className="absolute -bottom-10 -right-10 w-32 h-32 bg-[#00ff88]/10 rounded-full blur-[40px] group-hover:bg-[#00ff88]/20 transition-all pointer-events-none" />
      </div>
    </motion.div>
  );
}

export default function FeaturedApps() {
  const [activeCategory, setActiveCategory] = useState("All");
  const [searchQuery, setSearchQuery] = useState("");
  const [sortBy, setSortBy] = useState("Most Downloaded");
  const [toastMsg, setToastMsg] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setToastMsg(msg);
    setTimeout(() => setToastMsg(null), 3000);
  };

  const filteredApps = useMemo(() => {
    let result = FEATURED_APPS;
    
    // Category Filter
    if (activeCategory !== "All") {
      result = result.filter(app => app.category === activeCategory);
    }

    // Search Filter
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      result = result.filter(app => app.name.toLowerCase().includes(q));
    }

    // Sort
    if (sortBy === "Most Downloaded") {
      result = [...result].sort((a, b) => b.downloadsNum - a.downloadsNum);
    } else if (sortBy === "Top Rated") {
      result = [...result].sort((a, b) => b.rating - a.rating);
    }
    
    return result;
  }, [activeCategory, searchQuery, sortBy]);

  return (
    <section id="featured" className="py-24 px-4 relative z-10">
      <AnimatePresence>
        {toastMsg && (
          <motion.div 
            initial={{ opacity: 0, y: 50, x: "-50%" }}
            animate={{ opacity: 1, y: 0, x: "-50%" }}
            exit={{ opacity: 0, y: 50, x: "-50%" }}
            className="fixed bottom-10 left-1/2 bg-black border border-[#00ff88] text-[#00ff88] px-6 py-3 rounded-full shadow-[0_0_20px_rgba(0,255,136,0.3)] z-50 flex items-center gap-2 font-mono text-sm"
          >
            <div className="w-4 h-4 rounded-full border-2 border-[#00ff88] border-t-transparent animate-spin"></div>
            {toastMsg}
          </motion.div>
        )}
      </AnimatePresence>
      
      {/* Top Banner */}
      <div className="max-w-4xl mx-auto mb-16 bg-[#00ff88]/10 border border-[#00ff88]/30 rounded-xl p-4 flex items-center justify-center gap-3 shadow-[0_0_20px_rgba(0,255,136,0.1)]">
        <CheckCircle2 className="text-[#00ff88] w-5 h-5 flex-shrink-0" />
        <p className="text-[#00ff88] font-medium text-sm md:text-base">All apps updated to latest version &mdash; May 2026</p>
      </div>

      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-12">
          <motion.h2 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="font-display text-4xl md:text-5xl font-extrabold mb-4"
          >
            App <span className="text-transparent bg-clip-text bg-gradient-to-r from-[#00ff88] to-[#00cc66]">Directory</span>
          </motion.h2>
        </div>

        {/* Controls: Search, Filter, Sort */}
        <div className="flex flex-col md:flex-row items-center justify-between gap-4 mb-10 bg-black/40 backdrop-blur-md p-4 rounded-2xl border border-[#00ff88]/10 shadow-[0_0_30px_rgba(0,255,136,0.05)] z-20 relative">
          
          <div className="flex-1 w-full relative">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-[#00ff88]/50" />
            <input 
              type="text" 
              placeholder="Search for modded apps..." 
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-[#00ff88]/5 border border-[#00ff88]/20 rounded-xl pl-12 pr-4 py-3 text-white placeholder-[#00ff88]/40 outline-none focus:border-[#00ff88]/60 focus:ring-1 focus:ring-[#00ff88]/60 transition-all font-mono text-sm"
            />
          </div>

          <div className="flex items-center gap-4 w-full md:w-auto overflow-x-auto pb-2 md:pb-0 scrollbar-hide">
            {/* Categories */}
            <div className="flex gap-2">
              {CATEGORIES.map(cat => (
                <button
                  key={cat}
                  onClick={() => setActiveCategory(cat)}
                  className={`px-4 py-2 rounded-lg text-sm font-medium transition-all whitespace-nowrap ${
                    activeCategory === cat 
                      ? "bg-[#00ff88] text-black shadow-[0_0_15px_rgba(0,255,136,0.4)]" 
                      : "bg-[#00ff88]/5 text-[#00ff88]/70 hover:bg-[#00ff88]/10 hover:text-[#00ff88]"
                  }`}
                >
                  {cat}
                </button>
              ))}
            </div>

            <div className="w-px h-8 bg-white/10 hidden md:block" />

            {/* Sort Select */}
            <div className="relative flex items-center gap-2 flex-shrink-0">
              <Filter className="w-4 h-4 text-gray-400" />
              <select 
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value)}
                className="bg-transparent text-sm text-gray-300 font-medium focus:outline-none cursor-pointer appearance-none pr-4"
              >
                {SORT_OPTIONS.map(opt => <option key={opt} value={opt} className="bg-gray-900">{opt}</option>)}
              </select>
            </div>
          </div>
        </div>

        {/* App Grid */}
        {filteredApps.length > 0 ? (
          <motion.div layout className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            <AnimatePresence>
              {filteredApps.map((app, index) => (
                <AppCard key={app.id} app={app} index={index} onToast={showToast} />
              ))}
            </AnimatePresence>
          </motion.div>
        ) : (
          <div className="py-20 text-center text-gray-500">
            <p className="text-xl">No apps found matching your criteria.</p>
          </div>
        )}
      </div>
    </section>
  );
}
