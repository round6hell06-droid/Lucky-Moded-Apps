import { motion } from "motion/react";
import { ShieldCheck, Ban, Sparkles, RefreshCw, Zap, Server } from "lucide-react";

const FEATURES = [
  {
    icon: Ban,
    title: "Zero Ads. Period.",
    description: "Our mods entirely strip out intrusive banner ads, video interruptions, and sponsored spots across all apps.",
    tag: "EXPERIENCE"
  },
  {
    icon: ShieldCheck,
    title: "Safe & Verified",
    description: "Every APK is scanned with VirusTotal and passes through rigorous sandbox testing before it goes live.",
    tag: "SECURITY"
  },
  {
    icon: Sparkles,
    title: "Premium Unlocked",
    description: "Gain access to premium filters, uncompressed audio, unlimited skips, and pro-level editing tools natively.",
    tag: "CAPABILITY"
  },
  {
    icon: RefreshCw,
    title: "Fast OTA Updates",
    description: "Stay ahead of forced obsolescence. Get push notifications for over-the-air mod updates within 24 hours.",
    tag: "SYSTEM"
  },
  {
    icon: Zap,
    title: "Lightning Downloads",
    description: "Enterprise-grade CDNs ensure you download massive game caches and apps at maximum bandwidth speeds.",
    tag: "PERFORMANCE"
  },
  {
    icon: Server,
    title: "No Root Required",
    description: "Enjoy system-level modifications and unlocks without voiding your warranty or risking a device brick.",
    tag: "ACCESS"
  }
];

export default function Features() {
  return (
    <section id="features" className="py-24 px-4 relative z-10">
      <div className="max-w-7xl mx-auto">
        <motion.div 
          initial={{ opacity: 0, y: 30 }} 
          whileInView={{ opacity: 1, y: 0 }} 
          viewport={{ once: true, margin: "-100px" }}
          className="text-center mb-20"
        >
          <span className="text-[#00ff88] font-mono tracking-widest uppercase text-sm mb-4 block">Platform Architecture</span>
          <h2 className="font-display text-4xl md:text-5xl font-extrabold text-white">
            Meet Lucky Moded <span className="text-transparent bg-clip-text bg-gradient-to-r from-[#00ff88] to-[#00cc66]">Apps</span>
          </h2>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 text-left">
          {FEATURES.map((feat, index) => {
            const Icon = feat.icon;
            return (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 50 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: "-50px" }}
                transition={{ delay: index * 0.1, duration: 0.6, ease: "easeOut" }}
                whileHover={{ y: -5 }}
                className="group relative p-8 rounded-2xl bg-[#00ff88]/[0.03] border border-[#00ff88]/10 hover:border-[#00ff88]/40 hover:bg-[#00ff88]/[0.08] transition-all duration-300"
              >
                <div className="absolute top-0 right-0 p-4">
                   <span className="text-[10px] font-mono text-[#00ff88]/60 uppercase tracking-widest">{feat.tag}</span>
                </div>
                
                <div className="w-14 h-14 bg-black rounded-xl border border-[#00ff88]/30 flex items-center justify-center mb-6 shadow-[0_0_15px_rgba(0,255,136,0.1)] group-hover:shadow-[0_0_25px_rgba(0,255,136,0.3)] transition-all">
                   <Icon className="w-7 h-7 text-[#00ff88]" />
                </div>
                
                <h3 className="text-xl font-bold font-display tracking-wide mb-3 text-white group-hover:text-[#00ff88] transition-colors">{feat.title}</h3>
                <p className="text-sm text-gray-400 leading-relaxed group-hover:text-gray-300 transition-colors">
                  {feat.description}
                </p>
                
                {/* Glow effect matching IRIS bottom glow on cards */}
                <div className="absolute bottom-0 left-0 w-full h-1/2 bg-gradient-to-t from-[#00ff88]/5 to-transparent rounded-b-2xl opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none" />
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
