import { motion } from "motion/react";
import { Send } from "lucide-react";

export default function FloatingTelegram() {
  return (
    <motion.a
      href="https://t.me/LUCKYXMODZZ"
      target="_blank"
      rel="noopener noreferrer"
      initial={{ scale: 0, opacity: 0 }}
      animate={{ scale: 1, opacity: 1 }}
      transition={{ delay: 1, type: "spring", stiffness: 200, damping: 20 }}
      className="fixed bottom-6 right-6 z-[90] flex items-center gap-2 bg-[#00ff88] text-black px-4 py-3 rounded-full shadow-[0_0_20px_rgba(0,255,136,0.5)] hover:shadow-[0_0_30px_rgba(0,255,136,0.8)] hover:bg-[#00ffa3] hover:scale-105 transition-all animate-[pulse-glow_2s_infinite]"
    >
      <Send className="w-5 h-5 -ml-1 mt-0.5 -rotate-45" />
      <span className="font-bold text-sm pr-1">Join Us</span>
    </motion.a>
  );
}
