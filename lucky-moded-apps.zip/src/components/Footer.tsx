import { Terminal, Send } from "lucide-react";

export default function Footer() {
  return (
    <footer className="relative z-10 pt-24 pb-12 px-4 border-t border-[#00ff88]/20 bg-black backdrop-blur-md">
      <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-4 gap-12 md:gap-8 mb-16">
        
        {/* Brand */}
        <div className="col-span-1 md:col-span-2">
          <div className="flex items-center gap-3 mb-6">
            <div className="w-8 h-8 rounded-lg bg-[#00ff88]/10 border border-[#00ff88]/30 flex items-center justify-center text-[#00ff88]">
              <Terminal className="w-4 h-4" />
            </div>
            <span className="font-display font-bold text-xl tracking-wide text-white">
              Lucky Moded <span className="text-[#00ff88]">Apps</span>
            </span>
          </div>
          <p className="text-gray-400 text-sm max-w-sm">
            Providing unmodified access to premium features, secure downloads, and ad-free digital experiences worldwide.
          </p>
        </div>

        {/* Links 1 */}
        <div>
          <h4 className="text-white font-bold mb-6 tracking-wide">About</h4>
          <ul className="space-y-4 text-sm text-gray-400">
            <li><a href="#" className="hover:text-[#00ff88] transition-colors">Our Mission</a></li>
            <li><a href="#" className="hover:text-[#00ff88] transition-colors">How it Works</a></li>
            <li><a href="#" className="hover:text-[#00ff88] transition-colors">Security</a></li>
            <li><a href="#" className="hover:text-[#00ff88] transition-colors">Contact</a></li>
          </ul>
        </div>

        {/* Links 2 */}
        <div>
          <h4 className="text-white font-bold mb-6 tracking-wide">Company</h4>
          <ul className="space-y-4 text-sm text-gray-400">
            <li><a href="#" className="hover:text-[#00ff88] transition-colors">Terms of Service</a></li>
            <li><a href="#" className="hover:text-[#00ff88] transition-colors">Privacy Policy</a></li>
            <li><a href="https://t.me/LUCKYXMODZZ" target="_blank" rel="noopener noreferrer" className="hover:text-[#00ff88] transition-colors flex items-center gap-2"><Send className="w-3 h-3" /> Telegram Community</a></li>
            <li><a href="#" className="hover:text-[#00ff88] transition-colors">Careers</a></li>
          </ul>
        </div>
      </div>

      <div className="max-w-7xl mx-auto pt-8 border-t border-white/10 flex flex-col md:flex-row items-center justify-between gap-4">
        <p className="text-xs text-gray-600 font-mono">
          &copy; {new Date().getFullYear()} Lucky Moded Apps. All rights reserved.
        </p>
        
        {/* System Status matches IRIS dot */}
        <div className="flex items-center gap-2 px-3 py-1.5 rounded-full border border-white/5 bg-white/5">
          <div className="w-2 h-2 rounded-full bg-[#00ff88] shadow-[0_0_8px_#00ff88] animate-pulse" />
          <span className="text-xs text-[#00ff88] font-mono">System Operational</span>
        </div>
      </div>
    </footer>
  );
}
