import { motion } from "motion/react";

export default function GlowingSection() {
  return (
    <section className="py-32 relative z-10 flex text-center items-center justify-center min-h-[60vh]">
      <motion.div
        initial={{ opacity: 0, scale: 0.8 }}
        whileInView={{ opacity: 1, scale: 1 }}
        viewport={{ once: true }}
        transition={{ duration: 1 }}
        className="relative"
      >
        <div className="absolute inset-0 bg-[#00ff88]/20 blur-[150px] rounded-full pointer-events-none" />
        
        <h2 className="font-display font-black text-6xl md:text-8xl lg:text-9xl text-transparent bg-clip-text bg-gradient-to-b from-white to-gray-600 drop-shadow-[0_0_30px_rgba(0,255,136,0.3)] select-none">
          LUCKY<br />MODED
        </h2>
        <div className="font-mono text-[#00ff88] mt-6 tracking-[0.3em] text-sm md:text-base pulse-glow">
          [ SYSTEM NEURAL INTERFACE ]
        </div>
      </motion.div>
    </section>
  );
}
