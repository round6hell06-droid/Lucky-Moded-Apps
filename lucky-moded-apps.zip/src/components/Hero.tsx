import { useState, useEffect, useRef } from "react";
import { motion, useInView } from "motion/react";
import { Download, ChevronDown, Rocket } from "lucide-react";

function useCountUp(end: number, duration: number = 2000) {
  const [count, setCount] = useState(0);
  const ref = useRef(null);
  const inView = useInView(ref, { once: true, margin: "-50px" });

  useEffect(() => {
    if (!inView) return;
    let startTime: number;
    let animationFrame: number;
    const start = 0;
    
    const step = (timestamp: number) => {
      if (!startTime) startTime = timestamp;
      const progress = Math.min((timestamp - startTime) / duration, 1);
      setCount(Math.floor(progress * (end - start) + start));
      if (progress < 1) {
        animationFrame = window.requestAnimationFrame(step);
      }
    };
    animationFrame = window.requestAnimationFrame(step);
    return () => window.cancelAnimationFrame(animationFrame);
  }, [end, duration, inView]);

  return { count, ref };
}

function StatItem({ end, suffix, label }: { end: number, suffix: string, label: string }) {
  const { count, ref } = useCountUp(end, 2000);
  return (
    <div className="flex flex-col items-center">
      <div className="text-3xl md:text-4xl font-display font-bold text-white mb-1" ref={ref}>
        {count}{suffix}
      </div>
      <div className="text-xs md:text-sm text-[#00ff88] uppercase tracking-widest font-mono">
        {label}
      </div>
    </div>
  );
}

export default function Hero() {
  const [text, setText] = useState("");
  const fullText = "Lucky Moded Apps";
  
  useEffect(() => {
    let current = "";
    let i = 0;
    const interval = setInterval(() => {
      if (i < fullText.length) {
        current += fullText[i];
        setText(current);
        i++;
      } else {
        clearInterval(interval);
      }
    }, 80);
    return () => clearInterval(interval);
  }, []);

  return (
    <section className="relative pt-32 pb-20 md:pt-48 md:pb-32 px-4 flex flex-col items-center justify-center min-h-screen text-center z-10 overflow-hidden">
      
      {/* Background Glowing Blobs matching IRIS */}
      <div className="absolute top-1/4 left-1/4 w-[400px] h-[400px] bg-[#00ff88]/10 rounded-full blur-[100px] mix-blend-screen animate-blob pointer-events-none -z-10" />
      <div className="absolute top-1/3 right-1/4 w-[350px] h-[350px] bg-[#00cc66]/10 rounded-full blur-[100px] mix-blend-screen animate-blob pointer-events-none -z-10" style={{ animationDelay: "2s" }} />
      <div className="absolute bottom-1/4 left-1/2 -translate-x-1/2 w-[500px] h-[500px] bg-[#00ff88]/5 rounded-full blur-[120px] mix-blend-screen animate-blob pointer-events-none -z-10" style={{ animationDelay: "4s" }} />

      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.8 }}
        className="max-w-4xl mx-auto flex flex-col items-center relative"
      >
        {/* Animated Border Container */}
        <div className="absolute inset-0 bg-gradient-to-r from-transparent via-[#00ff88]/20 to-transparent blur-3xl -z-10" />

        <h1 className="font-display font-extrabold text-5xl md:text-7xl lg:text-8xl text-white mb-6 drop-shadow-[0_0_20px_rgba(0,255,136,0.3)] min-h-[1.2em]">
          {text}<span className="text-[#00ff88] animate-pulse">_</span>
        </h1>
        
        <h2 className="text-xl md:text-3xl text-white/90 font-medium mb-6">
          Premium Moded Apps. <span className="text-[#00ff88]">Unlimited Power.</span>
        </h2>

        <p className="text-lg text-gray-400 max-w-2xl mx-auto leading-relaxed mb-10">
          The ultimate distribution platform. Download premium features, unlocked games, and ad-free tools directly to your device without subscription fees.
        </p>

        <div className="flex flex-col sm:flex-row items-center gap-4 mb-20 w-full justify-center">
          <button className="w-full sm:w-auto bg-[#00ff88] text-black px-8 py-4 rounded-xl font-bold flex items-center justify-center gap-2 hover:bg-[#00ffa3] shadow-[0_0_30px_rgba(0,255,136,0.5)] transition-all transform hover:-translate-y-1">
            <Download className="w-5 h-5" />
            Download Now
          </button>
          <button className="w-full sm:w-auto bg-white/5 border border-[#00ff88]/30 hover:border-[#00ff88] text-white px-8 py-4 rounded-xl font-bold flex items-center justify-center gap-2 hover:bg-white/10 transition-all transform hover:-translate-y-1">
            <Rocket className="w-5 h-5 text-[#00ff88]" />
            How To Install
          </button>
        </div>

        {/* Stats Row */}
        <motion.div 
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.5 }}
          className="grid grid-cols-2 md:grid-cols-4 gap-8 md:gap-12 w-full pt-10 border-t border-[#00ff88]/20"
        >
          <StatItem end={500} suffix="+" label="Apps" />
          <StatItem end={10} suffix="M+" label="Downloads" />
          <StatItem end={100} suffix="%" label="Free" />
          <StatItem end={24} suffix="/7" label="Updated" />
        </motion.div>
      </motion.div>

      <motion.div 
        animate={{ y: [0, 10, 0] }}
        transition={{ repeat: Infinity, duration: 2 }}
        className="absolute bottom-10 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2 text-gray-500 hover:text-[#00ff88] transition-colors cursor-pointer"
        onClick={() => document.getElementById('terminal')?.scrollIntoView({ behavior: 'smooth' })}
      >
        <span className="text-xs font-mono uppercase tracking-widest text-[#00ff88]/70">Scroll to Explore</span>
        <ChevronDown className="w-5 h-5 text-[#00ff88]" />
      </motion.div>
    </section>
  );
}
