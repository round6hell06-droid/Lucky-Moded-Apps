import { motion } from "motion/react";

const MARQUEE_ITEMS = [
  "WhatsApp Plus",
  "Spotify Premium",
  "YouTube ReVanced",
  "Instagram Pro",
  "Netflix Premium",
  "PUBG Mobile Mod",
  "CapCut Pro",
  "Minecraft",
  "Clash of Clans Mod",
  "Canva Premium",
  "Discord Nitro",
  "GTA San Andreas"
];

export default function Marquee() {
  return (
    <section className="py-16 relative z-10 overflow-hidden border-y border-[#00ff88]/10 bg-[#00ff88]/[0.02] backdrop-blur-sm">
      <div className="flex w-fit animate-[marquee_40s_linear_infinite]">
        {/* Double the array for seamless looping */}
        {[...MARQUEE_ITEMS, ...MARQUEE_ITEMS, ...MARQUEE_ITEMS].map((item, idx) => (
          <div 
            key={idx} 
            className="flex items-center px-8 shrink-0"
          >
            <span className="font-display font-bold text-2xl md:text-4xl text-transparent bg-clip-text bg-gradient-to-r from-gray-500 to-gray-700 hover:from-[#00ff88] hover:to-[#00cc66] transition-colors duration-500 cursor-default whitespace-nowrap">
              {item}
            </span>
            <span className="ml-8 text-[#00ff88]/30 text-xl font-bold">✦</span>
          </div>
        ))}
      </div>
    </section>
  );
}
