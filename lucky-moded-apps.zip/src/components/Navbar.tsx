import { useState, useEffect } from "react";
import { motion } from "motion/react";
import { Github, Download, Menu, Terminal } from "lucide-react";

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 50);
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  return (
    <motion.nav 
      initial={{ y: -100 }}
      animate={{ y: 0 }}
      transition={{ duration: 0.6, ease: "easeOut" }}
      className={`fixed top-0 left-0 right-0 z-50 px-4 md:px-8 transition-colors duration-300 ${
        scrolled ? "bg-black/60 backdrop-blur-2xl border-b border-[#00ff88]/10 py-3" : "bg-transparent py-5"
      }`}
    >
      <div className="max-w-7xl mx-auto flex items-center justify-between">
        
        {/* Logo */}
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-lg bg-[#00ff88]/10 border border-[#00ff88]/30 flex items-center justify-center text-[#00ff88] shadow-[0_0_15px_rgba(0,255,136,0.3)]">
            <Terminal className="w-5 h-5" />
          </div>
          <span className="font-display font-bold text-xl tracking-wide text-white">
            Lucky Moded <span className="text-[#00ff88]">Apps</span>
          </span>
        </div>

        {/* Links */}
        <div className="hidden lg:flex items-center gap-8 text-sm font-medium text-gray-400">
          <a href="#" className="hover:text-white transition-colors">Home</a>
          <a href="#featured" className="hover:text-white transition-colors">Apps</a>
          <a href="#features" className="hover:text-white transition-colors">Features</a>
          <a href="#" className="hover:text-white transition-colors">How To Install</a>
          <a href="#" className="hover:text-white transition-colors">About</a>
        </div>

        {/* Actions */}
        <div className="flex items-center gap-4">
          <a href="#" className="hidden sm:flex p-2 text-gray-400 hover:text-white transition-colors">
            <Github className="w-5 h-5" />
          </a>
          <button className="hidden sm:flex items-center gap-2 bg-[#00ff88] text-black px-5 py-2.5 rounded-lg font-bold text-sm shadow-[0_0_20px_rgba(0,255,136,0.5)] hover:shadow-[0_0_30px_rgba(0,255,136,0.7)] hover:bg-[#00ffa3] transition-all transform hover:-translate-y-0.5">
            <Download className="w-4 h-4" />
            Download App
          </button>
          <button className="lg:hidden p-2 text-gray-400 hover:text-white">
            <Menu className="w-6 h-6" />
          </button>
        </div>

      </div>
    </motion.nav>
  );
}
