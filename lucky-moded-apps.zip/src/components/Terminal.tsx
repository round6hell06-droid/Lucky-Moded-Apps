import { useState, useEffect, useRef } from "react";
import { motion, useInView } from "motion/react";
import { Terminal as TerminalIcon } from "lucide-react";

export default function Terminal() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });
  
  const text = "> Connecting to Lucky servers...\n> Done.\n> Fetching latest mods...\n> 500+ apps found.\n> Ready to install.";
  const [displayedText, setDisplayedText] = useState("");

  useEffect(() => {
    if (!isInView) return;
    
    let i = 0;
    setDisplayedText(""); // reset on view
    
    // Quick random delay simulation for realism
    const interval = setInterval(() => {
      setDisplayedText(text.slice(0, i));
      i++;
      if (i > text.length) clearInterval(interval);
    }, 50);

    return () => clearInterval(interval);
  }, [isInView, text]);

  return (
    <section id="terminal" className="py-20 px-4 relative z-10">
      <div className="max-w-4xl mx-auto">
        <motion.div
          ref={ref}
          initial={{ opacity: 0, y: 50 }}
          animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 50 }}
          transition={{ duration: 0.8 }}
          className="rounded-xl bg-black border border-[#00ff88]/30 shadow-[0_0_40px_rgba(0,255,136,0.15)] overflow-hidden"
        >
          {/* Mac-like terminal header */}
          <div className="bg-[#111] border-b border-[#00ff88]/20 px-4 py-3 flex items-center gap-2">
            <div className="flex gap-2">
              <div className="w-3 h-3 rounded-full bg-red-500/80"></div>
              <div className="w-3 h-3 rounded-full bg-yellow-500/80"></div>
              <div className="w-3 h-3 rounded-full bg-green-500/80"></div>
            </div>
            <div className="flex-1 text-center text-xs text-gray-500 font-mono flex items-center justify-center gap-2">
              <TerminalIcon className="w-3 h-3" /> system@lucky-moded:~
            </div>
          </div>
          
          <div className="p-6 md:p-8 font-mono text-[#00ff88] text-sm md:text-base leading-relaxed whitespace-pre-line text-left min-h-[200px]">
             {displayedText}
             <span className="animate-pulse inline-block w-2.5 h-5 bg-[#00ff88] align-middle ml-1" />
          </div>
        </motion.div>
      </div>
    </section>
  );
}
