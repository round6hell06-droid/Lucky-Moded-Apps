export interface AppData {
  id: string;
  name: string;
  category: string;
  rating: number;
  downloadsText: string;
  downloadsNum: number;
  size: string;
  iconBg: string;
  iconUrl: string;
  version: string;
  badge?: "New" | "Hot" | "Updated";
  downloadUrl: string;
  modder: string;
  repoUrl: string;
}

const generateRandomBadge = (): "New" | "Hot" | "Updated" | undefined => {
  const rand = Math.random();
  if (rand > 0.8) return "Hot";
  if (rand > 0.6) return "New";
  if (rand > 0.4) return "Updated";
  return undefined;
};

const appsRaw = [
  // SOCIAL
  { name: "WhatsApp Plus", version: "v19.82", cat: "Social", domain: "whatsapp.com" },
  { name: "WhatsApp GB", version: "v19.85", cat: "Social", domain: "whatsapp.com" },
  { name: "Instagram Pro", version: "v358.1", cat: "Social", domain: "instagram.com" },
  { name: "Instagram Aero", version: "v360.0", cat: "Social", domain: "instagram.com" },
  { name: "Snapchat Premium", version: "v12.98.2", cat: "Social", domain: "snapchat.com" },
  { name: "Telegram Premium", version: "v10.22", cat: "Social", domain: "telegram.org" },
  { name: "Facebook Pro", version: "v485.2", cat: "Social", domain: "facebook.com" },
  { name: "Twitter X Premium", version: "v10.74", cat: "Social", domain: "x.com" },
  { name: "LinkedIn Premium", version: "v9.3", cat: "Social", domain: "linkedin.com" },
  { name: "Pinterest Pro", version: "v12.9.1", cat: "Social", domain: "pinterest.com" },
  { name: "Discord Nitro", version: "v240.5", cat: "Social", domain: "discord.com" },
  { name: "Skype Premium", version: "v8.115", cat: "Social", domain: "skype.com" },
  { name: "Viber Pro", version: "v22.1", cat: "Social", domain: "viber.com" },
  { name: "Signal Plus", version: "v7.1.3", cat: "Social", domain: "signal.org" },
  { name: "IMO Premium", version: "v2026.04", cat: "Social", domain: "imo.im" },

  // ENTERTAINMENT
  { name: "YouTube Vanced", version: "v19.06.34", cat: "Entertainment", domain: "youtube.com" },
  { name: "YouTube ReVanced", version: "v19.22.37", cat: "Entertainment", domain: "youtube.com" },
  { name: "Netflix Premium", version: "v8.110.0", cat: "Entertainment", domain: "netflix.com" },
  { name: "Amazon Prime", version: "v3.0.395", cat: "Entertainment", domain: "primevideo.com" },
  { name: "Disney Plus Pro", version: "v3.4.1", cat: "Entertainment", domain: "disneyplus.com" },
  { name: "Hotstar Premium", version: "v24.5.1", cat: "Entertainment", domain: "hotstar.com" },
  { name: "Spotify Premium", version: "v8.10.12", cat: "Entertainment", domain: "spotify.com" },
  { name: "Apple Music Mod", version: "v4.9.5", cat: "Entertainment", domain: "music.apple.com" },
  { name: "JioSaavn Pro", version: "v9.14", cat: "Entertainment", domain: "jiosaavn.com" },
  { name: "Gaana Plus", version: "v10.8", cat: "Entertainment", domain: "gaana.com" },
  { name: "Wynk Premium", version: "v3.9.1", cat: "Entertainment", domain: "wynk.in" },
  { name: "MX Player Pro", version: "v1.88.2", cat: "Entertainment", domain: "mxplayer.in" },
  { name: "VLC Pro", version: "v3.6.8", cat: "Entertainment", domain: "videolan.org" },
  { name: "Tidal Premium", version: "v2.115", cat: "Entertainment", domain: "tidal.com" },
  { name: "Deezer Premium", version: "v8.1.1", cat: "Entertainment", domain: "deezer.com" },

  // GAMES
  { name: "PUBG Mobile Mod", version: "v4.1.0", cat: "Games", domain: "pubgmobile.com" },
  { name: "Free Fire Max Mod", version: "v1.115.1", cat: "Games", domain: "ff.garena.com" },
  { name: "Minecraft Premium", version: "v1.22.10", cat: "Games", domain: "minecraft.net" },
  { name: "GTA Vice City Mod", version: "v1.15", cat: "Games", domain: "rockstargames.com" },
  { name: "GTA San Andreas Mod", version: "v2.13", cat: "Games", domain: "rockstargames.com" },
  { name: "Clash of Clans Mod", version: "v16.700.4", cat: "Games", domain: "supercell.com" },
  { name: "Clash Royale Mod", version: "v5.611.1", cat: "Games", domain: "supercell.com" },
  { name: "Among Us Mod", version: "v2026.3", cat: "Games", domain: "innersloth.com" },
  { name: "Roblox Premium", version: "v2.645", cat: "Games", domain: "roblox.com" },
  { name: "Call of Duty Mobile Mod", version: "v1.0.48", cat: "Games", domain: "callofduty.com" },
  { name: "Subway Surfers Mod", version: "v3.45.1", cat: "Games", domain: "sybogames.com" },
  { name: "Temple Run 2 Mod", version: "v5.12", cat: "Games", domain: "imangistudios.com" },
  { name: "Hill Climb Racing Mod", version: "v1.65.1", cat: "Games", domain: "fingersoft.com" },
  { name: "Candy Crush Mod", version: "v1.295", cat: "Games", domain: "king.com" },
  { name: "BGMI Mod", version: "v4.1.0", cat: "Games", domain: "battlegroundsmobileindia.com" },

  // TOOLS
  { name: "TurboVPN Premium", version: "v4.2.5", cat: "Tools", domain: "turbovpn.com" },
  { name: "NordVPN Mod", version: "v7.35", cat: "Tools", domain: "nordvpn.com" },
  { name: "ExpressVPN Mod", version: "v12.10.1", cat: "Tools", domain: "expressvpn.com" },
  { name: "Lucky Patcher", version: "v11.5.3", cat: "Tools", domain: "luckypatchers.com" },
  { name: "GameGuardian", version: "v105.0", cat: "Tools", domain: "gameguardian.net" },
  { name: "Alight Motion Pro", version: "v5.4.1", cat: "Tools", domain: "alightmotion.com" },
  { name: "CapCut Pro", version: "v13.5", cat: "Tools", domain: "capcut.com" },
  { name: "Kinemaster Premium", version: "v7.6.2", cat: "Tools", domain: "kinemaster.com" },
  { name: "PowerDirector Premium", version: "v14.1.5", cat: "Tools", domain: "cyberlink.com" },
  { name: "InShot Pro", version: "v2.091", cat: "Tools", domain: "inshot.com" },
  { name: "Canva Premium", version: "v2.285", cat: "Tools", domain: "canva.com" },
  { name: "Adobe Photoshop Mod", version: "v7.5", cat: "Tools", domain: "adobe.com" },
  { name: "PicsArt Premium", version: "v25.5", cat: "Tools", domain: "picsart.com" },
  { name: "Lightroom Premium", version: "v9.6.1", cat: "Tools", domain: "lightroom.adobe.com" },
  { name: "Snapseed Pro", version: "v3.0", cat: "Tools", domain: "snapseed.online" },

  // EDUCATION & UTILITY
  { name: "Duolingo Plus", version: "v5.205", cat: "Education", domain: "duolingo.com" },
  { name: "Grammarly Premium", version: "v3.15", cat: "Education", domain: "grammarly.com" },
  { name: "Google One Premium", version: "v1.350", cat: "Education", domain: "one.google.com" },
  { name: "Dropbox Plus", version: "v410.2", cat: "Education", domain: "dropbox.com" },
  { name: "Evernote Premium", version: "v11.10", cat: "Education", domain: "evernote.com" },
  { name: "LastPass Premium", version: "v5.18.1", cat: "Education", domain: "lastpass.com" },
  { name: "1Password Mod", version: "v8.12", cat: "Education", domain: "1password.com" },
  { name: "Microsoft Office Mod", version: "v16.0.192", cat: "Education", domain: "office.com" },
  { name: "WPS Office Premium", version: "v19.5.1", cat: "Education", domain: "wps.com" },
  { name: "Pdf Extra Premium", version: "v11.3", cat: "Education", domain: "mobisystems.com" },
  { name: "Turbo Cleaner Pro", version: "v3.5", cat: "Education", domain: "turbocleaner.com" },
  { name: "CCleaner Premium", version: "v25.10", cat: "Education", domain: "ccleaner.com" },
  { name: "ES File Explorer Pro", version: "v4.5.1", cat: "Education", domain: "esfileexplorer.com" },
  { name: "Solid Explorer Pro", version: "v2.9.15", cat: "Education", domain: "neatbytes.com" },
  { name: "Total Commander Pro", version: "v3.54", cat: "Education", domain: "ghisler.com" },
];

const gradients = [
  "bg-gradient-to-br from-[#00ff88]/80 to-[#00cc66]/80",
  "bg-gradient-to-br from-[#00cc66]/80 to-[#00aa55]/80",
  "bg-gradient-to-br from-[#00ffa3]/80 to-[#00ff88]/80",
  "bg-gradient-to-br from-[#00ff88]/90 to-[#008844]/90",
  "bg-gradient-to-br from-[#11ff99]/80 to-[#00dd77]/80",
];

export const FEATURED_APPS: AppData[] = appsRaw.map((app, index) => {
  const ratingNum = 4.0 + Math.random(); // 4.0 to 5.0
  const downloadsNum = Math.floor(10000 + Math.random() * 49990000); // 10K to 50M
  
  let downloadsText = "";
  if (downloadsNum >= 1000000) {
    downloadsText = (downloadsNum / 1000000).toFixed(1) + "M+";
  } else if (downloadsNum >= 1000) {
    downloadsText = Math.floor(downloadsNum / 1000) + "K+";
  } else {
    downloadsText = downloadsNum.toString() + "+";
  }

  const size = Math.floor(15 + Math.random() * 85) + " MB"; // 15MB to 100MB

  // Custom URLs
  const exactMatches: Record<string, string> = {
    "YouTube ReVanced": "https://getmodpc.net/youtube",
    "Instagram Pro": "https://getmodpc.net/instagram",
    "Instagram Aero": "https://getmodpc.net/instagram",
    "TikTok Mod": "https://getmodpc.net/tiktok",
    "Roblox Premium": "https://getmodpc.net/roblox",
    "Subway Surfers Mod": "https://getmodpc.net/subway-surfers",
    "WhatsApp Plus": "https://getmodpc.net/whatsapp-plus",
    "WhatsApp GB": "https://getmodpc.net/gbwhatsapp",
    "Snapchat Premium": "https://getmodpc.net/snapchat",
    "Telegram Premium": "https://getmodpc.net/telegram",
    "Facebook Pro": "https://getmodpc.net/facebook",
    "Twitter X Premium": "https://getmodpc.net/twitter",
    "Discord Nitro": "https://getmodpc.net/discord",
    "Spotify Premium": "https://getmodpc.net/spotify",
    "Netflix Premium": "https://getmodpc.net/netflix",
    "Amazon Prime": "https://getmodpc.net/amazon-prime-video",
    "Disney Plus Pro": "https://getmodpc.net/disney-plus",
    "Hotstar Premium": "https://getmodpc.net/hotstar",
    "CapCut Pro": "https://getmodpc.net/capcut",
    "Kinemaster Premium": "https://getmodpc.net/kinemaster",
    "Alight Motion Pro": "https://getmodpc.net/alight-motion",
    "InShot Pro": "https://getmodpc.net/inshot",
    "Canva Premium": "https://getmodpc.net/canva",
    "Lightroom Premium": "https://getmodpc.net/lightroom",
    "PicsArt Premium": "https://getmodpc.net/picsart",
    "YouTube Music Premium": "https://getmodpc.net/youtube-music",
    "VLC Pro": "https://getmodpc.net/vlc",
    "MX Player Pro": "https://getmodpc.net/mx-player",
    "Minecraft Premium": "https://getmodpc.net/minecraft",
    "PUBG Mobile Mod": "https://getmodpc.net/pubg-mobile",
    "Free Fire Max Mod": "https://getmodpc.net/free-fire",
    "Clash of Clans Mod": "https://getmodpc.net/clash-of-clans",
    "Clash Royale Mod": "https://getmodpc.net/clash-royale",
    "Among Us Mod": "https://getmodpc.net/among-us",
    "Call of Duty Mobile Mod": "https://getmodpc.net/call-of-duty-mobile",
    "Mobile Legends Mod": "https://getmodpc.net/mobile-legends",
    "Hill Climb Racing Mod": "https://getmodpc.net/hill-climb-racing",
    "Candy Crush Mod": "https://getmodpc.net/candy-crush-saga",
    "Temple Run 2 Mod": "https://getmodpc.net/temple-run-2",
    "NordVPN Mod": "https://getmodpc.net/nordvpn",
    "Duolingo Plus": "https://getmodpc.net/duolingo",
    "Grammarly Premium": "https://getmodpc.net/grammarly",
    "Microsoft Office Mod": "https://getmodpc.net/microsoft-office",
    "WPS Office Premium": "https://getmodpc.net/wps-office",
    "Snaptube Mod": "https://getmodpc.net/snaptube",
    "PowerDirector Premium": "https://getmodpc.net/powerdirector",
    "Block Blast Mod": "https://getmodpc.net/block-blast",
  };

  const defaultUrl = "https://getmodpc.net";
  const downloadUrl = exactMatches[app.name] || defaultUrl;

  const modders = ["@LuckyTeam", "@AlexMods", "@TeamVanced", "@ProMods", "@ReVancedTeam", "@AeroTeam"];
  const modder = modders[index % modders.length];
  const repoUrl = `https://github.com/lucky-moded-apps/${app.name.toLowerCase().replace(/\s+/g, '-')}`;

  return {
    id: app.name.toLowerCase().replace(/\s+/g, '-'),
    name: app.name,
    category: app.cat,
    rating: parseFloat(ratingNum.toFixed(1)),
    downloadsText,
    downloadsNum,
    size,
    iconBg: gradients[index % gradients.length],
    iconUrl: `https://www.google.com/s2/favicons?sz=128&domain=${app.domain}`,
    version: app.version,
    badge: generateRandomBadge(),
    downloadUrl,
    modder,
    repoUrl
  };
});
